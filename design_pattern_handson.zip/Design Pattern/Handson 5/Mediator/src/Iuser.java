public interface Iuser {

	void receiveMessage(String msg);
	void sendMessage(String msg);
}
