package com.cognizant.invoke;

import java.util.Scanner;
import com.cognizant.classes.PhoneOrderRepair;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner kb=new Scanner(System.in);
		System.out.println("Welcome to our site.Would you like to order or repair?");
		String processOption=kb.nextLine().toLowerCase().trim();
		PhoneOrderRepair phoneorderrepair = new PhoneOrderRepair();
		String productDetail=null;
		
		switch(processOption)
		{
		case "order":
			System.out.println("Please provide the phone model name");
			productDetail=kb.nextLine().trim();
			phoneorderrepair.processOrder(productDetail);
			break;
		case "repair":
			System.out.println("Is it the phone or the accessory that you want to be repaired?");
			String productType=kb.nextLine().toLowerCase();
			if(productType.equals("phone"))
			{
				System.out.println("Please provide the phone model name");
				productDetail=kb.nextLine().trim();
				phoneorderrepair.processPhoneRepair(productDetail);
			}
			else
			{
				System.out.println("Please provide the accessory detail, like headphone,tempered glass");
				productDetail=kb.nextLine().trim();
				phoneorderrepair.processAccessoryRepair(productDetail);
			}
			break;
			default :
				break;
		}
	}
}
