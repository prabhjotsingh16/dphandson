public class ProjectManager implements ILeaveRequestHandler {

	private ILeaveRequestHandler nextHandler=new HR();
	
	@Override
	public void HandleRequest(LeaveRequest leaverequest)
	{
		int d=leaverequest.getLeavedays();
		if(d<5)
		{
			System.out.println("Leave Approved by Project Manager for :: "+leaverequest.getEmployee());
		}
		else {
			nextHandler.HandleRequest(leaverequest);
		}
	}
}
