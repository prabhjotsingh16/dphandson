
public abstract class Tire {

}
