public class BasicUser implements Iuser {

	private ChatMediator chatmediator;
	private String name;
	
	public BasicUser()
	{
		super();
	}
	
	public void receiveMessage(String msg)
	{
		System.out.println(name+ " recieved : "+msg);
	}
	
	public void sendMessage(String msg)
	{
		chatmediator.sendMessage(msg);
	}
	public BasicUser(ChatMediator chatMediator, String name) {
		super();
		this.chatmediator = chatMediator;
		this.name = name;
	}
}
