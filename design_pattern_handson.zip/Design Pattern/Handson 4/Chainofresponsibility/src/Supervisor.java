public class Supervisor implements ILeaveRequestHandler {

	private ILeaveRequestHandler nextHandler=new ProjectManager();
	
	@Override
	public void HandleRequest(LeaveRequest leaverequest)
	{
		int d=leaverequest.getLeavedays();
		if(d>0 && d<3)
		{
			System.out.println("Leave Approved by Supervisor for :: "+leaverequest.getEmployee());
		}
		else {
			nextHandler.HandleRequest(leaverequest);
		}
	}
}
