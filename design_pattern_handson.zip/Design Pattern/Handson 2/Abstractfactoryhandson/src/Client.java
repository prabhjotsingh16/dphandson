public class Client {

	public static void main(String[] args) {
		
		Factory factory=new MercedesFactory();
		System.out.println(factory.makeHeadLight());
		System.out.println(factory.makeTire());
		Factory factory1=new AudiFactory();
		System.out.println(factory1.makeHeadLight());
		System.out.println(factory1.makeTire());
	}
}
