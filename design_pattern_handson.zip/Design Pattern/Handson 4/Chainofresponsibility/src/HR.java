public class HR implements ILeaveRequestHandler{

	private ILeaveRequestHandler nextHandler=null;
	
	@Override
	public void HandleRequest(LeaveRequest leaverequest)
	{
		int d=leaverequest.getLeavedays();
		if(d>7)
		{
			System.out.println("Meet HR for leave");
		}
		else
		{
			System.out.println("Leave Approved By HR for :: "+leaverequest.getEmployee());
		}
	}
}
