public interface IChatMediator {

	void addUser(Iuser id);
	void sendMessage(String msg);
}
