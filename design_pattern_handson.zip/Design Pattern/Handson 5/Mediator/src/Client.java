public class Client {
	public static void main(String args[]) {
		ChatMediator chatMediator = new ChatMediator();
		BasicUser bUser = new BasicUser(chatMediator, "BUser");
		PremiumUser pUser = new PremiumUser(chatMediator, "PUser");
		BasicUser buser1=new BasicUser(chatMediator,"Purusham");
		chatMediator.addUser(bUser);
		chatMediator.addUser(pUser);
		//chatMediator.addUser(suraj);
		
	buser1.sendMessage("Hi All,My name is Prabhjot");
		//pUser.sendMessage("USer HH sent message");

		//chatMediator.sendMessage("i wanted to send message to you all");

	}
}
