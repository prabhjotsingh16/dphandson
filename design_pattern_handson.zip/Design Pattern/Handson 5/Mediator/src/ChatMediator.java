import java.util.*;

public class ChatMediator implements IChatMediator {

	private List<Iuser> users=new ArrayList<Iuser>();
	
	public ChatMediator() {}
	
	@Override
	public void addUser(Iuser id)
	{
		 users.add(id);
	}
	
	public List<Iuser> getUsers()
	{
		return users; 
	}
	
	@Override
	public void sendMessage(String msg)
	{
		for(Iuser user:users)
		{
			user.receiveMessage(msg);
		}
	}
}
