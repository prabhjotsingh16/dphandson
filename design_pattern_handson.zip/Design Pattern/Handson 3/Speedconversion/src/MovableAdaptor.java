public interface MovableAdaptor {

	public double getSpeed();
	public double getPrice();
}
