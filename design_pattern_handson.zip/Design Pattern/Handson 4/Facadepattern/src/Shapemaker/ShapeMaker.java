package Shapemaker;

import Interfaces.Shape;
import Interfaces.Square;
import Interfaces.Rectangle;
import Interfaces.Circle;

public class ShapeMaker {

	private Shape circle;
	private Shape rectangle;
	private Shape square;
	
	public void Shapemaker() {}
	
	public void drawCircle()
	{
		circle=new Circle();
		circle.draw();
	}
	public void drawRectangle()
	{
		rectangle=new Rectangle();
		rectangle.draw();
	}
	public void drawSquare()
	{
		square=new Square();
		square.draw();
	}
}
