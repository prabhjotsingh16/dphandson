public class LeaveRequest {

	private String employee;
	private int leavedays;
	public String getEmployee() {
		return employee;
	}
	public void setEmployee(String employee) {
		this.employee = employee;
	}
	public int getLeavedays() {
		return leavedays;
	}
	public void setLeavedays(int leavedays) {
		this.leavedays = leavedays;
	}
}
