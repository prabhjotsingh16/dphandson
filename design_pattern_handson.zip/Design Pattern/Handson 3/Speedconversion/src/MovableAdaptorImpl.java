public class MovableAdaptorImpl implements MovableAdaptor {

	private Movable luxurycars;
	
	public MovableAdaptorImpl(Movable luxurycars)
	{
		super();
		this.luxurycars=luxurycars;
	}
	
	@Override
	public double getSpeed()
	{
		return convertMPHtoKMPH(luxurycars.getSpeed());
	}
	
	private double convertMPHtoKMPH(double mph) { 
		return mph * 1.60934;
	}
	@Override
	public double getPrice()
	{
		return convertUSDtoEURO(luxurycars.getPrice());
	}
	
	private double convertUSDtoEURO(double usd)
	{
		return usd*0.92;
	}
}
