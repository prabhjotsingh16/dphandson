public class PremiumUser implements Iuser {

	private ChatMediator chatMediator;
	private String name;

	public PremiumUser() {
		super();
	}

	@Override
	public void receiveMessage(String msgr) {
		
		System.out.println(name+ " recieved : "+ msgr);
	}
	
	public PremiumUser(ChatMediator chatMediator, String name) {
		super();
		this.chatMediator = chatMediator;
		this.name = name;
	}

	@Override
	public void sendMessage(String msgs) {
		
		chatMediator.sendMessage(msgs);
	}
}

