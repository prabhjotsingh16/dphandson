public class Program {

	public static void main(String[] args) {
			LeaveRequest leaveRequest=new LeaveRequest();
			leaveRequest.setEmployee("Prabhjot");
			leaveRequest.setLeavedays(3);
			ILeaveRequestHandler supervisor=new Supervisor();
			supervisor.HandleRequest(leaveRequest);
	}

}
