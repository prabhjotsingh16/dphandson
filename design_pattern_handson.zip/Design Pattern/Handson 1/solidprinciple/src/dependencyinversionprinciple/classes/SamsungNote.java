package dependencyinversionprinciple.classes;

import dependencyinversionprinciple.interfaces.Iphone;

public class SamsungNote implements Iphone {
	
	public double getPart1Cost()
	{
		return 500;
	}
	public String getPhonePart1()
	{
		return "Display";
	}
}
