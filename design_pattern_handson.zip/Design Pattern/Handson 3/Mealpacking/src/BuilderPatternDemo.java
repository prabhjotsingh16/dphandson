public class BuilderPatternDemo {

	public static void main(String[] args) {
		
		MealBuilder mealbuilder=new MealBuilder();
		Meal vegMeal=mealbuilder.prepareVegMeal();
		System.out.println("Veg Meal");
		vegMeal.showItems();
		System.out.println("Total Cost: " + vegMeal.getCost());
		
		Meal nonvegMeal=mealbuilder.prepareNonvegMeal();
		System.out.println("NonVeg Meal");
		nonvegMeal.showItems();
		System.out.println("Total Cost: " + nonvegMeal.getCost());
	}

}
